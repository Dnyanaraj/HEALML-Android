# Implementation Plan: Fix ML Evaluation, 3-Class Random Forest & Isolation Forest Anomaly Engine

Resolve critical Random Forest metrics bugs (0% precision/recall/F1, missing 3-class evaluation for `diabetic_data.csv`), repair Isolation Forest anomaly decision logic and contamination calibration, and enforce single-source-of-truth dashboard metric consistency.

***

### User Review & Critical Decisions

> [!IMPORTANT]
> The following confirmed decisions govern this update:

- **Confirmed Decision 1 (Random Forest Architecture)**: Support real 3-class classification (`NO`, `>30`, `<30` for diabetic readmission) with balanced class weights (`class_weight='balanced'`), stratified train-test split, real 3×3 confusion matrix, per-class classification report (precision, recall, f1, support), and both macro-averaged and weighted-averaged metrics.
- **Confirmed Decision 2 (Isolation Forest Calibration)**: Strict adherence to Scikit-Learn convention: `fit_predict(X)` returns `-1` (anomalous) and `1` (normal) calibrated to `contamination=0.08`. Normal count, anomaly count, and percentage are computed directly from actual prediction vectors with zero hardcoded offsets.
- **Confirmed Decision 3 (diabetic_data.csv & Scale Handling)**: In the browser client, large datasets like `diabetic_data.csv` (101,766 rows) utilize a stratified representative sample (5,000 records) to preserve sub-second real-time responsiveness without freezing the UI thread, while the Python backend pipeline processes all 101,766 records in batch.
- **Confirmed Decision 4 (Preservation Guarantee)**: Maintain all existing dark navy UI layouts, sidebar styling, SQLite recovery logs, and automated self-healing remediation routines intact.

***

## 1. Overview & Core Concept

### What It Does
This release refactors the core Machine Learning and Anomaly Detection engines in both the interactive TypeScript client and the exportable Python Flask backend:
1. **Multiclass & 3-Class Random Forest**: Replaces naive binarization with true multiclass decision trees and stratified splitting. Automatically detects 3-class targets (`NO`, `>30`, `<30`) or binary targets, calculating true class frequencies, balanced inverse-frequency weights, per-class precision/recall/F1, macro/weighted averages, and interactive 3×3 (or 2×2) confusion matrix heatmaps.
2. **Proper Isolation Forest Predictions**: Inverts the scoring formula and aligns with Scikit-learn's exact `fit_predict(X)` semantics: samples with path length $h(x) < \text{threshold}$ (or score below $1 - \text{contamination}$) are labeled `-1` (anomaly), ensuring exactly $\approx 8\%$ contamination rate rather than 100% false positives.
3. **Cross-View Metric Consistency**: Binds Overview Dashboard, Model Evaluation, Isolation Forest Explorer, and SQLite audit logging to a single unified execution state with execution timestamps, training status badges, and comprehensive error boundaries.

***

## 2. User Experience & Visual Design

### Key User Flows
1. **Dataset Ingestion (`diabetic_data.csv` / Samples)**:
   - Ingests dataset with `readmitted` target column (`NO`, `>30`, `<30`).
   - Automatically detects 3 distinct target classes and generates class distribution bar pills.
2. **3-Class Model Evaluation**:
   - Displays real 3×3 Confusion Matrix: Actual rows vs Predicted columns for `NO`, `>30`, and `<30`.
   - Classification Report table showing Precision, Recall, F1-Score, and Support for each individual class.
   - Summary cards displaying Macro F1, Weighted F1, Overall Accuracy, and Execution Latency.
3. **Calibrated Isolation Forest Explorer**:
   - Displays exact Normal Count ($1$) and Anomaly Count ($-1$) based on real isolation trees.
   - Shows calibrated contamination percentage (nominally 8.0%), score distribution, and outlier explanation based on real feature deviations.
4. **Dashboard Synchronization**:
   - Overview Dashboard KPI cards instantly reflect the real multiclass accuracy, weighted F1, and calibrated anomaly counts with timestamped status.

***

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Multiclass Confusion Matrix Matrix Extension**:
  - *Chosen Approach*: Expand `ModelMetrics` to support arbitrary $K \times K$ confusion matrices with class labels (`labels: string[]`, `matrix: number[][]`, `perClassMetrics: { label: string; precision: number; recall: number; f1: number; support: number }[]`, `macroF1: number`, `weightedF1: number`).
  - *Why*: Accommodates 3-class diabetic readmissions (`NO`, `>30`, `<30`) as well as existing 2-class datasets (`0`, `1`) without breaking UI rendering.
- **Decision 2: Balanced Class Weighting**:
  - *Chosen Approach*: Compute sample class weights inversely proportional to class frequencies: $w_c = \frac{N}{K \cdot N_c}$.
  - *Why*: In `diabetic_data.csv`, `<30` is a minority class (~11%). Without balanced weights, greedy trees default to majority `NO` (~54%), collapsing precision/recall for minority classes to 0%.

***

## 4. Technical Architecture & Implementation Details

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Unified ML Pipeline State                         │
│  • dataset (diabetic_data / health / loan / iot)  • target: 'readmitted'    │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
         ┌─────────────────────────────┴─────────────────────────────┐
         ▼                                                           ▼
┌───────────────────────────────────────────┐ ┌───────────────────────────────┐
│       Random Forest (Multiclass)          │ │       Isolation Forest        │
│ • Stratified 75/25 Train-Test Split       │ │ • contamination = 0.08        │
│ • Balanced Class Weights w_c = N/(K*N_c)  │ │ • fit_predict: -1 (anom),     │
│ • Real 3x3 Confusion Matrix               │ │                 1 (normal)    │
│ • Per-Class & Macro/Weighted Metrics      │ │ • Accurate 8% anomaly rate    │
└─────────────────────┬─────────────────────┘ └──────────────┬────────────────┘
                      │                                      │
                      └──────────────────┬───────────────────┘
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                    Synchronized UI Telemetry & SQLite Store                 │
│ • DashboardView: Total Records, Quality, Anomaly Count, Macro/Weighted F1  │
│ • ModelEvaluationView: 3x3 Heatmap, Classification Report Table            │
│ • AnomalyDetectorView: Real Normal/Anomaly ratio with -1 / 1 filters        │
│ • SQLite Audit Ledger: Persistent run logs with verified deltas            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Files to Modify
1. `src/types/pipeline.ts`: Expand `ModelMetrics` to support multiclass matrices (`matrix: number[][]`, `labels: string[]`, `perClassMetrics`, `macroF1`, `weightedF1`, `lastExecutionTimestamp`, `trainingStatus`).
2. `src/services/mlEngine.ts`:
   - Implement stratified multiclass train-test split.
   - Implement balanced class weighting in Gini impurity calculation.
   - Refactor Random Forest to output multiclass probability distributions and predictions across $K$ classes.
   - Fix Isolation Forest scoring: compute path lengths, sort anomaly threshold at exactly the 8th percentile (`contamination=0.08`), and set predictions to `-1` and `1`.
3. `src/components/ModelEvaluationView.tsx`: Render dynamic $K \times K$ confusion matrix heatmap (including 3×3 for `NO`, `>30`, `<30`), full classification report table, and macro/weighted summary metrics.
4. `src/components/AnomalyDetectorView.tsx`: Display accurate Normal Count ($1$) and Anomaly Count ($-1$) with correct percentage and no false-positive overflow.
5. `src/components/DashboardView.tsx`: Bind directly to unified model metrics and display last execution timestamp and training status.
6. `src/services/projectExporter.ts`: Update Python backend `pipeline.py` and `app.py` to use `RandomForestClassifier(class_weight='balanced')`, 3-class target handling, and `IsolationForest(contamination=0.08)`.
