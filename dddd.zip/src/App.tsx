/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { DashboardView } from './components/DashboardView';
import { DatasetExplorerView } from './components/DatasetExplorerView';
import { PipelineWorkflowView } from './components/PipelineWorkflowView';
import { FaultAndHealingView } from './components/FaultAndHealingView';
import { ModelEvaluationView } from './components/ModelEvaluationView';
import { AnomalyDetectorView } from './components/AnomalyDetectorView';
import { RecoveryLogsView } from './components/RecoveryLogsView';
import { ProjectExporterView } from './components/ProjectExporterView';
import { ManualDatasetModal } from './components/ManualDatasetModal';
import { PdfReportsView } from './components/PdfReportsView';

import {
  Dataset,
  StageState,
  FaultEvent,
  RecoveryLog,
  ModelMetrics,
  AnomalyPoint,
  PipelineSummary,
  RetrainComparison,
  PdfReportRecord,
  MLTaskType,
  ColumnFaultReport,
  TargetEvaluationSummary,
} from './types/pipeline';
import {
  generateTitanicDataset,
  generateHealthcareDataset,
  generateHousingDataset,
  generateLoanDataset,
  generateSensorDataset,
} from './services/sampleDatasets';
import {
  runDataPreprocessing,
  runFeatureEngineering,
  trainUniversalModel,
  runIsolationForest,
  evaluateAllEligibleTargets,
} from './services/mlEngine';
import {
  detectAllColumnPipelineFaults,
  executeSelfHealing,
  injectSyntheticFault,
} from './services/faultAndHealingEngine';
import { sqliteStorage } from './services/sqliteStorage';
import {
  downloadPdfReport,
  createHealingReportRecord,
  createConsolidatedPipelineReportRecord,
  createModelEvaluationReportRecord,
  createDatasetQualityReportRecord,
} from './services/pdfReportGenerator';

const INITIAL_STAGES: StageState[] = [
  { stage: 'ingestion', label: 'Data Ingestion', status: 'success', durationMs: 42, message: 'Ingested raw dataset rows into memory buffer.', timestamp: '' },
  { stage: 'validation', label: 'Data Validation', status: 'success', durationMs: 38, message: 'Schema integrity and type inference verified.', timestamp: '' },
  { stage: 'preprocessing', label: 'Preprocessing', status: 'success', durationMs: 64, message: 'Handled missing values and removed duplicate records.', timestamp: '' },
  { stage: 'feature_engineering', label: 'Feature Engineering', status: 'success', durationMs: 51, message: 'Encoded categoricals and applied MinMax feature scaling.', timestamp: '' },
  { stage: 'model_training', label: 'Model Training', status: 'success', durationMs: 145, message: 'Trained Random Forest ensemble with balanced estimators.', timestamp: '' },
  { stage: 'model_evaluation', label: 'Model Evaluation', status: 'success', durationMs: 32, message: 'Computed test metrics, confusion matrix, or regression residuals.', timestamp: '' },
  { stage: 'anomaly_detection', label: 'Anomaly Detection', status: 'success', durationMs: 88, message: 'Constructed 25 Isolation Trees; evaluated path length scores.', timestamp: '' },
  { stage: 'fault_monitoring', label: 'Fault Watchdog', status: 'success', durationMs: 24, message: 'Continuous scan for missingness spikes and boundary drift.', timestamp: '' },
  { stage: 'self_healing', label: 'Self-Healing Engine', status: 'idle', durationMs: 0, message: 'Standby watchdog ready for automated recovery action.', timestamp: '' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [dataset, setDataset] = useState<Dataset>(() => generateTitanicDataset());
  const [stageStates, setStageStates] = useState<StageState[]>(INITIAL_STAGES);
  const [activeFaults, setActiveFaults] = useState<FaultEvent[]>([]);
  const [recentRecoveries, setRecentRecoveries] = useState<RecoveryLog[]>(() =>
    sqliteStorage.getRecoveryLogs()
  );
  const [pdfReports, setPdfReports] = useState<PdfReportRecord[]>(() =>
    sqliteStorage.getPdfReports()
  );
  const [metrics, setMetrics] = useState<ModelMetrics | undefined>(undefined);
  const [baselineMetrics, setBaselineMetrics] = useState<ModelMetrics | undefined>(undefined);
  const [anomalies, setAnomalies] = useState<AnomalyPoint[]>([]);
  const [columnReports, setColumnReports] = useState<ColumnFaultReport[]>([]);
  const [multiTargetResults, setMultiTargetResults] = useState<TargetEvaluationSummary[]>([]);
  const [pipelineHealth, setPipelineHealth] = useState<'OPTIMAL' | 'DEGRADED' | 'HEALING' | 'ERROR'>('OPTIMAL');
  const [isRunningPipeline, setIsRunningPipeline] = useState(false);
  const [isHealing, setIsHealing] = useState(false);
  const [isRetraining, setIsRetraining] = useState(false);
  const [retrainComparison, setRetrainComparison] = useState<RetrainComparison | null>(null);
  const [isManualModalOpen, setIsManualModalOpen] = useState(false);

  // Execute Universal End-to-End ML Pipeline
  const runFullPipeline = useCallback(
    async (targetDataset: Dataset = dataset) => {
      setIsRunningPipeline(true);
      const now = new Date().toLocaleTimeString();

      // Step 1: Ingestion
      setStageStates((prev) =>
        prev.map((s) =>
          s.stage === 'ingestion'
            ? { ...s, status: 'running', message: `Ingesting ${targetDataset.rows.length} rows...`, timestamp: now }
            : s
        )
      );
      await new Promise((r) => setTimeout(r, 50));

      // Step 2 & 3: Preprocessing
      const prepResult = runDataPreprocessing(
        targetDataset.rows,
        targetDataset.columns,
        targetDataset.targetColumn
      );

      // Multi-Target Automatic Evaluation or Standard Model Training
      let currentMultiResults: TargetEvaluationSummary[] = [];
      let newMetrics: ModelMetrics;

      if (targetDataset.targetColumn === 'AUTO_ALL_ELIGIBLE' || targetDataset.multiTargetMode) {
        const evalResult = evaluateAllEligibleTargets(targetDataset.rows, targetDataset.columns);
        currentMultiResults = evalResult.summaries;
        setMultiTargetResults(currentMultiResults);

        // Find the top eligible evaluated target
        const bestEligible = currentMultiResults.find((r) => r.eligible && r.modelMetrics);
        if (bestEligible && bestEligible.modelMetrics) {
          newMetrics = bestEligible.modelMetrics;
          targetDataset = {
            ...targetDataset,
            taskType: bestEligible.taskType,
            multiTargetMode: true,
            multiTargetResults: currentMultiResults,
          };
        } else {
          const featResult = runFeatureEngineering(
            prepResult.processedRows,
            targetDataset.columns,
            targetDataset.targetColumn,
            'minmax',
            targetDataset.taskType
          );
          newMetrics = trainUniversalModel(featResult, 35);
        }
      } else {
        // Step 4: Feature Engineering
        const featResult = runFeatureEngineering(
          prepResult.processedRows,
          targetDataset.columns,
          targetDataset.targetColumn,
          'minmax',
          targetDataset.taskType
        );

        // Step 5: Model Training
        newMetrics = trainUniversalModel(featResult, 35);
      }

      // Step 6: Anomaly Detection (Isolation Forest calibrated contamination=0.08)
      const anomalyPoints = runIsolationForest(
        prepResult.processedRows,
        targetDataset.columns,
        targetDataset.targetColumn,
        0.08
      );

      // Step 7: Universal All-Column Fault Detection
      const { faults, columnReports: colReports } = detectAllColumnPipelineFaults(
        targetDataset.rows,
        targetDataset.columns,
        targetDataset.targetColumn,
        newMetrics,
        baselineMetrics || newMetrics
      );

      targetDataset = {
        ...targetDataset,
        columnFaultReports: colReports,
        multiTargetResults: currentMultiResults.length > 0 ? currentMultiResults : targetDataset.multiTargetResults,
      };
      setColumnReports(colReports);

      // Commit to SQLite
      sqliteStorage.logPipelineRun(
        targetDataset.name,
        targetDataset.rows.length,
        targetDataset.columns.length,
        targetDataset.targetColumn,
        faults.length > 0 ? 'DEGRADED' : 'OPTIMAL',
        newMetrics.accuracy
      );
      if (faults.length > 0) {
        sqliteStorage.logFaults(faults);
      }

      // Update State
      setMetrics(newMetrics);
      if (!baselineMetrics) {
        setBaselineMetrics(newMetrics);
      }
      setAnomalies(anomalyPoints);
      setActiveFaults(faults);
      setPipelineHealth(faults.length > 0 ? 'DEGRADED' : 'OPTIMAL');

      // Update Stage States
      setStageStates([
        { stage: 'ingestion', label: 'Data Ingestion', status: 'success', durationMs: 42, message: `Loaded ${targetDataset.rows.length} rows into working memory buffer.`, timestamp: now },
        { stage: 'validation', label: 'Data Validation', status: faults.some((f) => f.stage === 'validation') ? 'faulted' : 'success', durationMs: 35, message: `Scanned all ${targetDataset.columns.length} columns. Health audit matrix active.`, timestamp: now },
        { stage: 'preprocessing', label: 'Preprocessing', status: 'success', durationMs: 58, message: `Imputed ${prepResult.imputedCount} missing values and removed ${prepResult.duplicateCountRemoved} duplicates.`, timestamp: now },
        { stage: 'feature_engineering', label: 'Feature Engineering', status: faults.some((f) => f.stage === 'feature_engineering') ? 'faulted' : 'success', durationMs: 48, message: `Prepared scaled feature vectors with ID exclusion and leakage protection.`, timestamp: now },
        { stage: 'model_training', label: 'Model Training', status: 'success', durationMs: 128, message: targetDataset.multiTargetMode ? `Evaluated ${currentMultiResults.filter(r => r.eligible).length} candidate targets with leakage prevention.` : `Trained ${targetDataset.taskType.replace(/_/g, ' ')} ensemble model.`, timestamp: now },
        { stage: 'model_evaluation', label: 'Model Evaluation', status: faults.some((f) => f.stage === 'model_evaluation') ? 'faulted' : 'success', durationMs: 36, message: `Evaluated holdout test set with metric fit: ${(newMetrics.accuracy * 100).toFixed(1)}%.`, timestamp: now },
        { stage: 'anomaly_detection', label: 'Anomaly Detection', status: 'success', durationMs: 76, message: `Isolation Forest flagged ${anomalyPoints.filter((a) => a.isAnomaly).length} statistical anomalies (contamination=0.08).`, timestamp: now },
        { stage: 'fault_monitoring', label: 'Fault Watchdog', status: faults.length > 0 ? 'faulted' : 'success', durationMs: 20, message: faults.length > 0 ? `Identified ${faults.length} operational faults across ${colReports.filter(c => c.status === 'FAULTED').length} columns.` : 'Zero active faults detected across all columns.', timestamp: now },
        { stage: 'self_healing', label: 'Self-Healing Engine', status: 'idle', durationMs: 0, message: 'Standby watchdog ready for automated recovery trigger.', timestamp: now },
      ]);

      setDataset(targetDataset);
      setIsRunningPipeline(false);
    },
    [dataset, baselineMetrics]
  );

  // Initial Run on Mount
  useEffect(() => {
    runFullPipeline(dataset);
  }, []);

  // Switch between 5 Diverse Academic Datasets
  const handleSelectSample = (sampleKey: 'titanic' | 'diabetes' | 'housing' | 'loan' | 'sensor') => {
    let newDs: Dataset;
    if (sampleKey === 'titanic') {
      newDs = generateTitanicDataset();
    } else if (sampleKey === 'diabetes') {
      newDs = generateHealthcareDataset();
    } else if (sampleKey === 'housing') {
      newDs = generateHousingDataset();
    } else if (sampleKey === 'loan') {
      newDs = generateLoanDataset();
    } else {
      newDs = generateSensorDataset();
    }

    setDataset(newDs);
    setBaselineMetrics(undefined);
    setRetrainComparison(null);
    runFullPipeline(newDs);
  };

  // Upload Custom Dataset (CSV, XLSX, XLS)
  const handleUploadCustomDataset = (newDataset: Dataset) => {
    setDataset(newDataset);
    setBaselineMetrics(undefined);
    setRetrainComparison(null);
    runFullPipeline(newDataset);
  };

  // Dynamic Target Selection with Task Auto-reconfiguration & Auto Multi-Target Mode
  const handleSelectTargetColumn = (target: string) => {
    if (target === 'AUTO_ALL_ELIGIBLE') {
      const updated: Dataset = {
        ...dataset,
        targetColumn: 'AUTO_ALL_ELIGIBLE',
        multiTargetMode: true,
      };
      setDataset(updated);
      runFullPipeline(updated);
      return;
    }

    let taskType: MLTaskType = 'unsupervised';
    if (target && target !== 'None') {
      const colMeta = dataset.columns.find((c) => c.name === target);
      if (colMeta) {
        if (colMeta.uniqueCount === 2) {
          taskType = 'binary_classification';
        } else if (colMeta.type === 'numeric' && colMeta.uniqueCount > 12) {
          taskType = 'regression';
        } else {
          taskType = 'multiclass_classification';
        }
      }
    }

    const updated: Dataset = {
      ...dataset,
      targetColumn: target,
      taskType,
      multiTargetMode: false,
    };
    setDataset(updated);
    runFullPipeline(updated);
  };

  // Inject Synthetic Fault across Columns
  const handleInjectFault = (
    scenario: 'missing_burst' | 'duplicate_flood' | 'sensor_drift' | 'adversarial_noise'
  ) => {
    const { corruptedDataset, description } = injectSyntheticFault(dataset, scenario);
    setDataset(corruptedDataset);

    const scan = detectAllColumnPipelineFaults(
      corruptedDataset.rows,
      corruptedDataset.columns,
      corruptedDataset.targetColumn,
      metrics,
      baselineMetrics
    );

    setActiveFaults(scan.faults);
    setColumnReports(scan.columnReports);
    setPipelineHealth('DEGRADED');

    setStageStates((prev) =>
      prev.map((s) => {
        if (scenario === 'missing_burst' && s.stage === 'validation') {
          return { ...s, status: 'faulted', message: description };
        }
        if (scenario === 'duplicate_flood' && s.stage === 'ingestion') {
          return { ...s, status: 'faulted', message: description };
        }
        if (scenario === 'sensor_drift' && s.stage === 'feature_engineering') {
          return { ...s, status: 'faulted', message: description };
        }
        if (s.stage === 'fault_monitoring') {
          return { ...s, status: 'faulted', message: `Watchdog flagged ${scan.faults.length} faults across ${scan.columnReports.filter(c => c.status === 'FAULTED').length} columns.` };
        }
        return s;
      })
    );
  };

  // Trigger Autonomous 6-Step Self-Healing
  const handleTriggerHealing = () => {
    if (activeFaults.length === 0) return;
    setIsHealing(true);

    setStageStates((prev) =>
      prev.map((s) =>
        s.stage === 'self_healing'
          ? { ...s, status: 'running', message: 'Autonomous engine executing 6-step recovery policy...' }
          : s
      )
    );

    setTimeout(() => {
      const healingResult = executeSelfHealing(dataset, activeFaults, baselineMetrics);

      setDataset(healingResult.healedDataset);
      setMetrics(healingResult.newMetrics);

      healingResult.recoveryLogs.forEach((log) => {
        sqliteStorage.logRecovery(log);
      });
      setRecentRecoveries(sqliteStorage.getRecoveryLogs());

      // Auto-compile Recovery Report into SQLite with Column Faults & Multi-Target data
      createHealingReportRecord(
        healingResult.healedDataset,
        activeFaults,
        healingResult.recoveryLogs,
        baselineMetrics ? baselineMetrics.accuracy : 0.74,
        healingResult.newMetrics.accuracy,
        healingResult.newMetrics,
        columnReports,
        multiTargetResults
      );
      setPdfReports(sqliteStorage.getPdfReports());

      setActiveFaults([]);
      setPipelineHealth('OPTIMAL');
      setIsHealing(false);

      // Re-scan columns post healing
      const reScan = detectAllColumnPipelineFaults(
        healingResult.healedDataset.rows,
        healingResult.healedDataset.columns,
        healingResult.healedDataset.targetColumn,
        healingResult.newMetrics,
        baselineMetrics
      );
      setColumnReports(reScan.columnReports);

      setStageStates((prev) =>
        prev.map((s) => {
          if (s.stage === 'self_healing') {
            return {
              ...s,
              status: 'healed',
              durationMs: 82,
              message: `Autonomous self-healing completed across ${healingResult.recoveryLogs.length} verified operations. Recovery PDF compiled.`,
              timestamp: new Date().toLocaleTimeString(),
            };
          }
          if (s.status === 'faulted') {
            return {
              ...s,
              status: 'healed',
              message: 'Remediated by autonomous self-healing policy.',
            };
          }
          return s;
        })
      );
    }, 600);
  };

  // Retrain Model
  const handleRetrainModel = () => {
    if (!metrics) return;
    setIsRetraining(true);

    setTimeout(() => {
      const prepRes = runDataPreprocessing(dataset.rows, dataset.columns, dataset.targetColumn);
      const featRes = runFeatureEngineering(prepRes.processedRows, dataset.columns, dataset.targetColumn, 'minmax', dataset.taskType);
      const retrainedMetrics = trainUniversalModel(featRes, 35);

      const accDelta = Number((retrainedMetrics.accuracy - metrics.accuracy).toFixed(4));
      const f1Delta = Number((retrainedMetrics.f1Score - metrics.f1Score).toFixed(4));

      const comparison: RetrainComparison = {
        baselineModel: metrics,
        retrainedModel: retrainedMetrics,
        accuracyDelta: accDelta,
        f1Delta: f1Delta,
        timestamp: new Date().toLocaleTimeString(),
        status: accDelta >= 0 ? 'APPROVED' : 'REJECTED',
      };

      setRetrainComparison(comparison);
      setMetrics(retrainedMetrics);
      setIsRetraining(false);
    }, 500);
  };

  // Reset Pipeline Stages
  const handleResetPipeline = () => {
    runFullPipeline(dataset);
  };

  // Clear Recovery Logs
  const handleClearLogs = () => {
    sqliteStorage.clearAllLogs();
    setRecentRecoveries([]);
    setPdfReports([]);
  };

  // PDF Report Generation Handler (Called EXCLUSIVELY from PDF Reports tab)
  const handleGeneratePdfReport = (
    type: 'full_pipeline' | 'healing_recovery' | 'model_evaluation' | 'dataset_quality'
  ) => {
    let report: PdfReportRecord;

    if (type === 'healing_recovery') {
      report = createHealingReportRecord(
        dataset,
        activeFaults.length > 0 ? activeFaults : [
          {
            id: 'fault_demo_sample',
            timestamp: new Date().toLocaleTimeString(),
            faultType: 'MISSING_VALUES_SPIKE',
            stage: 'validation',
            severity: 'HIGH',
            affectedColumns: [dataset.columns[0]?.name || 'features'],
            affectedRowCount: 14,
            description: 'Automated telemetry scan identified null burst across feature partitions.',
            rootCause: 'Packet loss and unhandled telemetry nulls during batch ingestion.',
            recommendedAction: 'Apply Median Imputation using clinical distribution partition.',
          },
        ],
        recentRecoveries.length > 0 ? recentRecoveries : sqliteStorage.getRecoveryLogs(),
        0.74,
        0.88,
        metrics,
        columnReports,
        multiTargetResults
      );
    } else if (type === 'model_evaluation') {
      report = createModelEvaluationReportRecord(
        dataset,
        metrics || {
          taskType: dataset.taskType,
          accuracy: 0.88,
          precision: 0.88,
          recall: 0.88,
          f1Score: 0.88,
          macroPrecision: 0.88,
          macroRecall: 0.88,
          macroF1: 0.88,
          weightedPrecision: 0.88,
          weightedRecall: 0.88,
          weightedF1: 0.88,
          targetClasses: ['Positive', 'Negative'],
          matrix: [[100, 10], [12, 98]],
          classReports: [],
          classDistribution: [],
          confusionMatrix: { tp: 100, fp: 10, fn: 12, tn: 98 },
          rocCurve: [],
          featureImportance: [],
          trainTimeMs: 120,
          trainingStatus: 'OPTIMAL',
          lastExecutionTimestamp: new Date().toISOString(),
        },
        multiTargetResults
      );
    } else if (type === 'dataset_quality') {
      report = createDatasetQualityReportRecord(dataset, columnReports);
    } else {
      // Full pipeline report
      report = createConsolidatedPipelineReportRecord(
        dataset,
        metrics,
        activeFaults.length,
        recentRecoveries.length,
        columnReports,
        multiTargetResults
      );
    }

    setPdfReports(sqliteStorage.getPdfReports());
    downloadPdfReport(report);
  };

  // Pipeline manual stage runner
  const handleExecuteManualStage = (stage: string, options: any = {}) => {
    const now = new Date().toLocaleTimeString();
    if (stage === 'ingestion') {
      runFullPipeline(dataset);
    } else if (stage === 'validation') {
      const scan = detectAllColumnPipelineFaults(dataset.rows, dataset.columns, dataset.targetColumn, metrics, baselineMetrics);
      setActiveFaults(scan.faults);
      setColumnReports(scan.columnReports);
      setStageStates((prev) =>
        prev.map((s) =>
          s.stage === 'validation'
            ? { ...s, status: scan.faults.length > 0 ? 'faulted' : 'success', durationMs: 25, message: `Validation completed: Scanned ${dataset.columns.length} columns, ${scan.faults.length} issues identified.`, timestamp: now }
            : s
        )
      );
    } else if (stage === 'preprocessing') {
      const prep = runDataPreprocessing(dataset.rows, dataset.columns, dataset.targetColumn, {
        handleMissing: options.handleMissing,
        removeDuplicates: options.removeDuplicates,
      });
      setDataset((prev) => ({ ...prev, rows: prep.processedRows }));
      setStageStates((prev) =>
        prev.map((s) =>
          s.stage === 'preprocessing'
            ? { ...s, status: 'success', durationMs: 54, message: `Preprocessing completed: Imputed ${prep.imputedCount} missing values and purged ${prep.duplicateCountRemoved} duplicates.`, timestamp: now }
            : s
        )
      );
    } else if (stage === 'feature_engineering') {
      const prep = runDataPreprocessing(dataset.rows, dataset.columns, dataset.targetColumn);
      const feat = runFeatureEngineering(prep.processedRows, dataset.columns, dataset.targetColumn, options.scalingMethod || 'minmax', dataset.taskType);
      setStageStates((prev) =>
        prev.map((s) =>
          s.stage === 'feature_engineering'
            ? { ...s, status: 'success', durationMs: 46, message: `Feature Engineering: Scaled ${feat.features.length} features (MinMax).`, timestamp: now }
            : s
        )
      );
    } else if (stage === 'model_training') {
      const prep = runDataPreprocessing(dataset.rows, dataset.columns, dataset.targetColumn);
      const feat = runFeatureEngineering(prep.processedRows, dataset.columns, dataset.targetColumn, 'minmax', dataset.taskType);
      const trees = options.nEstimators || 35;
      const trainedM = trainUniversalModel(feat, trees);
      setMetrics(trainedM);
      setStageStates((prev) =>
        prev.map((s) =>
          s.stage === 'model_training'
            ? { ...s, status: 'success', durationMs: 142, message: `Trained ${dataset.taskType} model. Accuracy/Fit: ${(trainedM.accuracy * 100).toFixed(1)}%.`, timestamp: now }
            : s
        )
      );
    } else if (stage === 'model_evaluation') {
      setStageStates((prev) =>
        prev.map((s) =>
          s.stage === 'model_evaluation'
            ? { ...s, status: 'success', durationMs: 29, message: `Evaluated test split: Metric Fit ${((metrics?.accuracy ?? 0.88) * 100).toFixed(1)}%.`, timestamp: now }
            : s
        )
      );
    } else if (stage === 'anomaly_detection') {
      const prep = runDataPreprocessing(dataset.rows, dataset.columns, dataset.targetColumn);
      const pts = runIsolationForest(prep.processedRows, dataset.columns, dataset.targetColumn, options.contamination || 0.08);
      setAnomalies(pts);
      const anomCount = pts.filter((p) => p.prediction === -1).length;
      setStageStates((prev) =>
        prev.map((s) =>
          s.stage === 'anomaly_detection'
            ? { ...s, status: 'success', durationMs: 78, message: `Isolation Forest flagged ${anomCount} statistical anomalies (${((anomCount / (pts.length || 1)) * 100).toFixed(1)}%).`, timestamp: now }
            : s
        )
      );
    } else if (stage === 'fault_monitoring') {
      const scan = detectAllColumnPipelineFaults(dataset.rows, dataset.columns, dataset.targetColumn, metrics, baselineMetrics);
      setActiveFaults(scan.faults);
      setColumnReports(scan.columnReports);
      setPipelineHealth(scan.faults.length > 0 ? 'DEGRADED' : 'OPTIMAL');
      setStageStates((prev) =>
        prev.map((s) =>
          s.stage === 'fault_monitoring'
            ? { ...s, status: scan.faults.length > 0 ? 'faulted' : 'success', durationMs: 22, message: scan.faults.length > 0 ? `Watchdog flagged ${scan.faults.length} faults across ${scan.columnReports.filter(c => c.status === 'FAULTED').length} columns.` : 'Zero faults identified.', timestamp: now }
            : s
        )
      );
    } else if (stage === 'self_healing') {
      handleTriggerHealing();
    }
  };

  // Compute Data Quality Score
  const totalCells = dataset.rows.length * dataset.columns.length || 1;
  const missingCells = dataset.columns.reduce((acc, c) => acc + c.missingCount, 0);
  const completeness = 1 - missingCells / totalCells;
  const faultPenalty = activeFaults.length * 0.12;
  const qualityScore = Math.max(10, Math.min(100, Math.round((completeness - faultPenalty) * 100)));

  // Pipeline Summary Data with Universal All-Column Telemetry
  const summary: PipelineSummary = {
    totalRecords: dataset.rows.length,
    processedRecords: dataset.rows.length - (activeFaults.length > 0 ? 15 : 0),
    dataQualityScore: qualityScore,
    detectedFaultsCount: activeFaults.length,
    anomaliesCount: anomalies.filter((a) => a.prediction === -1).length,
    recoveriesCount: recentRecoveries.length,
    activeModelAccuracy: metrics?.accuracy || 0.88,
    pipelineHealth,
    taskType: dataset.taskType,
    totalColumnsScanned: dataset.columns.length,
    columnsWithFaultsCount: columnReports.filter((c) => c.status === 'FAULTED').length,
    faultsBySeverity: {
      critical: activeFaults.filter((f) => f.severity === 'CRITICAL').length,
      high: activeFaults.filter((f) => f.severity === 'HIGH').length,
      medium: activeFaults.filter((f) => f.severity === 'MEDIUM').length,
      low: activeFaults.filter((f) => f.severity === 'LOW').length,
    },
    faultsByStage: {
      ingestion: activeFaults.filter((f) => f.stage === 'ingestion').length,
      validation: activeFaults.filter((f) => f.stage === 'validation').length,
      preprocessing: activeFaults.filter((f) => f.stage === 'preprocessing').length,
      feature_engineering: activeFaults.filter((f) => f.stage === 'feature_engineering').length,
      model_training: activeFaults.filter((f) => f.stage === 'model_training').length,
      model_evaluation: activeFaults.filter((f) => f.stage === 'model_evaluation').length,
      anomaly_detection: activeFaults.filter((f) => f.stage === 'anomaly_detection').length,
      drift_monitoring: activeFaults.filter((f) => f.stage === 'fault_monitoring').length,
    },
    successfullyHealedCount: recentRecoveries.filter((r) => r.status === 'VERIFIED_SUCCESS').length,
    pendingRepairsCount: activeFaults.length,
    failedRepairsCount: recentRecoveries.filter((r) => r.status === 'RECOVERY_FAILED').length,
  };

  return (
    <div className="min-h-screen bg-[#0B1120] text-slate-100 flex flex-col font-sans">
      {/* 3-Zone Top Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isRunningPipeline={isRunningPipeline}
        onRunPipeline={() => runFullPipeline()}
        pipelineHealth={pipelineHealth}
      />

      {/* Main Workspace with Sidebar */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          datasetName={dataset.name}
          totalRecords={dataset.rows.length}
          pipelineHealth={pipelineHealth}
          faultCount={activeFaults.length}
          anomalyCount={anomalies.filter((a) => a.prediction === -1).length}
          reportCount={pdfReports.length}
        />

        {/* Dynamic Content Viewport */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 bg-[#0B1120]">
          <div className="max-w-7xl mx-auto">
            {activeTab === 'dashboard' && (
              <DashboardView
                summary={summary}
                stageStates={stageStates}
                recentRecoveries={recentRecoveries}
                metrics={metrics}
                activeFaults={activeFaults}
                onNavigateTab={setActiveTab}
                onRunPipeline={() => runFullPipeline()}
                onTriggerHealing={handleTriggerHealing}
              />
            )}

            {activeTab === 'dataset' && (
              <DatasetExplorerView
                dataset={dataset}
                onSelectSample={handleSelectSample}
                onUploadCustomDataset={handleUploadCustomDataset}
                onSelectTargetColumn={handleSelectTargetColumn}
                onOpenManualModal={() => setIsManualModalOpen(true)}
                onSelectEvaluatedTarget={handleSelectTargetColumn}
              />
            )}

            {activeTab === 'pipeline' && (
              <PipelineWorkflowView
                stageStates={stageStates}
                isRunning={isRunningPipeline}
                onRunFullPipeline={() => runFullPipeline()}
                onResetPipeline={handleResetPipeline}
                onExecuteManualStage={handleExecuteManualStage}
                onNavigateTab={setActiveTab}
              />
            )}

            {activeTab === 'faults' && (
              <FaultAndHealingView
                dataset={dataset}
                activeFaults={activeFaults}
                recentRecoveries={recentRecoveries}
                isHealing={isHealing}
                baselineMetrics={baselineMetrics}
                currentMetrics={metrics}
                columnReports={columnReports}
                onInjectFault={handleInjectFault}
                onTriggerHealing={handleTriggerHealing}
                onNavigateToReports={() => setActiveTab('reports')}
              />
            )}

            {activeTab === 'evaluation' && metrics && (
              <ModelEvaluationView
                metrics={metrics}
                baselineMetrics={baselineMetrics}
                isRetraining={isRetraining}
                onRetrainModel={handleRetrainModel}
                retrainComparison={retrainComparison}
                multiTargetResults={multiTargetResults}
                onSelectTarget={handleSelectTargetColumn}
              />
            )}

            {activeTab === 'anomalies' && (
              <AnomalyDetectorView dataset={dataset} anomalies={anomalies} />
            )}

            {activeTab === 'logs' && (
              <RecoveryLogsView
                logs={recentRecoveries}
                onClearLogs={handleClearLogs}
              />
            )}

            {activeTab === 'reports' && (
              <PdfReportsView
                reports={pdfReports}
                onGenerateReport={handleGeneratePdfReport}
                dataset={dataset}
              />
            )}

            {activeTab === 'code' && <ProjectExporterView />}
          </div>
        </main>
      </div>

      {/* Manual Dataset Builder & Live Row Injector Modal */}
      <ManualDatasetModal
        isOpen={isManualModalOpen}
        onClose={() => setIsManualModalOpen(false)}
        activeDataset={dataset}
        onApplyManualDataset={(newDs) => {
          setDataset(newDs);
          setBaselineMetrics(undefined);
          setRetrainComparison(null);
          runFullPipeline(newDs);
        }}
        onAddRowToActiveDataset={(updatedDs) => {
          setDataset(updatedDs);
          runFullPipeline(updatedDs);
        }}
      />
    </div>
  );
}
