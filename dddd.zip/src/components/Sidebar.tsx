/**
 * HEALML - Sidebar Component
 * Provides clean MLOps navigation, active dataset indicator,
 * and pipeline health status monitoring.
 */

import React from 'react';
import {
  LayoutDashboard,
  Database,
  GitFork,
  Activity,
  BarChart3,
  Search,
  History,
  FileCode2,
  FolderGit2,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  RefreshCw,
  FileText,
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  datasetName: string;
  totalRecords: number;
  pipelineHealth: 'OPTIMAL' | 'DEGRADED' | 'HEALING' | 'ERROR';
  faultCount: number;
  anomalyCount: number;
  reportCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  datasetName,
  totalRecords,
  pipelineHealth,
  faultCount,
  anomalyCount,
  reportCount = 0,
}) => {
  const menuItems = [
    { id: 'dashboard', label: 'Overview Dashboard', icon: LayoutDashboard },
    { id: 'dataset', label: 'Dataset Explorer', icon: Database },
    { id: 'pipeline', label: 'Pipeline Workflow', icon: GitFork },
    { id: 'faults', label: 'Faults & Self-Healing', icon: Activity, badge: faultCount > 0 ? `${faultCount}` : undefined },
    { id: 'evaluation', label: 'Model Evaluation', icon: BarChart3 },
    { id: 'anomalies', label: 'Isolation Forest', icon: Search, badge: anomalyCount > 0 ? `${anomalyCount}` : undefined },
    { id: 'logs', label: 'Recovery Logs (SQLite)', icon: History },
    { id: 'reports', label: 'PDF Reports', icon: FileText, badge: reportCount > 0 ? `${reportCount}` : undefined },
    { id: 'code', label: 'Python Flask Code & Guides', icon: FileCode2 },
  ];

  return (
    <aside className="w-64 bg-[#0F172A] border-r border-slate-800 flex flex-col shrink-0 min-h-[calc(100vh-57px)]">
      {/* Current Dataset Context */}
      <div className="p-4 border-b border-slate-800/80">
        <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider mb-1.5 flex items-center justify-between">
          <span>Active Dataset</span>
          <span className="font-mono text-blue-400 tabular-nums">{totalRecords} rows</span>
        </div>
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-200 truncate" title={datasetName}>
          <FolderGit2 className="w-4 h-4 text-blue-400 shrink-0" />
          <span className="truncate">{datasetName}</span>
        </div>
      </div>

      {/* Navigation Links */}
      <div className="flex-1 px-3 py-4 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-blue-600/15 text-blue-400 border border-blue-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-blue-400' : 'text-slate-500'}`} />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge && (
                <span className="text-[10px] font-mono font-semibold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Pipeline Status Indicator Panel */}
      <div className="p-4 border-t border-slate-800 bg-slate-900/50">
        <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider mb-2">
          Pipeline State
        </div>
        <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-800/70 border border-slate-700/60">
          <div className="flex items-center gap-2">
            {pipelineHealth === 'OPTIMAL' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
            {pipelineHealth === 'DEGRADED' && <AlertTriangle className="w-4 h-4 text-amber-400" />}
            {pipelineHealth === 'HEALING' && <RefreshCw className="w-4 h-4 text-blue-400 animate-spin" />}
            {pipelineHealth === 'ERROR' && <AlertCircle className="w-4 h-4 text-rose-400" />}
            <span className="text-xs font-semibold text-slate-200">{pipelineHealth}</span>
          </div>
          <span className="text-[10px] font-mono text-slate-400">
            {pipelineHealth === 'OPTIMAL' ? 'Nominal' : pipelineHealth === 'HEALING' ? 'Repairing' : 'Degraded'}
          </span>
        </div>
      </div>
    </aside>
  );
};
