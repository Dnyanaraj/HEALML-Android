/**
 * HEALML – Universal Dataset Explorer & Automatic Target Analyzer
 * Handles dataset upload (CSV, XLSX, XLS), sample switching across 5 domains,
 * dynamic Target Feature selector with AUTO EVALUATE ALL ELIGIBLE TARGETS,
 * multi-target leaderboard, and schema statistics.
 */

import React, { useState } from 'react';
import {
  Upload,
  Database,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Search,
  Filter,
  ChevronLeft,
  ChevronRight,
  Info,
  Sparkles,
  Sliders,
  Layers,
  ArrowRight,
  Check,
  Ban,
  ShieldAlert,
  Download,
} from 'lucide-react';
import { Dataset, DataColumn, DataRow, TargetEvaluationSummary } from '../types/pipeline';
import { parseCsvContent, parseExcelContent } from '../services/datasetParser';
import { downloadHealedDatasetCsv, downloadHealedDatasetXlsx } from '../services/healedDatasetExporter';

interface DatasetExplorerViewProps {
  dataset: Dataset;
  onSelectSample: (sampleKey: 'titanic' | 'diabetes' | 'housing' | 'loan' | 'sensor' | 'student_mental' | 'student_dropout' | 'clean_benchmark') => void;
  onUploadCustomDataset: (newDataset: Dataset) => void;
  onSelectTargetColumn: (target: string) => void;
  onOpenManualModal: () => void;
  onSelectEvaluatedTarget?: (target: string) => void;
}

export const DatasetExplorerView: React.FC<DatasetExplorerViewProps> = ({
  dataset,
  onSelectSample,
  onUploadCustomDataset,
  onSelectTargetColumn,
  onOpenManualModal,
  onSelectEvaluatedTarget,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const rowsPerPage = 12;

  // Handle CSV, XLSX, or XLS file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const fileName = file.name.toLowerCase();
    const isCsv = fileName.endsWith('.csv');
    const isExcel = fileName.endsWith('.xlsx') || fileName.endsWith('.xls');

    if (!isCsv && !isExcel) {
      setUploadError('Unsupported format. Please upload a .csv, .xlsx, or .xls file.');
      return;
    }

    const reader = new FileReader();
    if (isCsv) {
      reader.onload = (event) => {
        try {
          const content = event.target?.result as string;
          const parsed = parseCsvContent(content, file.name);
          onUploadCustomDataset(parsed);
          setUploadError(null);
        } catch (err: any) {
          setUploadError(err.message || 'Failed to parse CSV file.');
        }
      };
      reader.readAsText(file);
    } else {
      // Excel binary
      reader.onload = (event) => {
        try {
          const buffer = event.target?.result as ArrayBuffer;
          const parsed = parseExcelContent(buffer, file.name);
          onUploadCustomDataset(parsed);
          setUploadError(null);
        } catch (err: any) {
          setUploadError(err.message || 'Failed to parse Excel workbook.');
        }
      };
      reader.readAsArrayBuffer(file);
    }
  };

  // Filter rows based on search query
  const filteredRows = dataset.rows.filter((r) => {
    if (!searchQuery) return true;
    return Object.values(r).some((v) =>
      String(v ?? '').toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const totalPages = Math.ceil(filteredRows.length / rowsPerPage) || 1;
  const paginatedRows = filteredRows.slice(
    (currentPage - 1) * rowsPerPage,
    currentPage * rowsPerPage
  );

  // Compute data completeness
  const totalCells = dataset.rows.length * dataset.columns.length || 1;
  const missingCells = dataset.columns.reduce((acc, c) => acc + c.missingCount, 0);
  const completeness = Number(((1 - missingCells / totalCells) * 100).toFixed(1));

  const isMultiTargetMode = dataset.targetColumn === 'AUTO_ALL_ELIGIBLE';

  return (
    <div className="space-y-6">
      {/* Top Dataset Management Header */}
      <div className="p-5 rounded-xl bg-[#0F172A] border border-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-blue-400 font-semibold uppercase tracking-wider">
                {dataset.domain}
              </span>
              <span className="text-slate-600">·</span>
              <span className="text-xs font-mono text-emerald-400">
                Mode: {isMultiTargetMode ? 'MULTI-TARGET EVALUATION' : dataset.taskType.replace(/_/g, ' ').toUpperCase()}
              </span>
            </div>
            <h1 className="text-xl font-bold tracking-tight text-white mt-1">
              {dataset.name}
            </h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              {dataset.description}
            </p>
          </div>

          {/* Academic & Benchmark Sample Datasets Switcher */}
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-xs text-slate-400 mr-1 text-[11px] font-mono">Sample:</span>
            <button
              onClick={() => onSelectSample('titanic')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-all ${
                dataset.id === 'titanic_survival'
                  ? 'bg-blue-600/25 text-blue-300 border-blue-500/50 font-semibold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              Titanic
            </button>
            <button
              onClick={() => onSelectSample('diabetes')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-all ${
                dataset.id === 'diabetic_data'
                  ? 'bg-blue-600/25 text-blue-300 border-blue-500/50 font-semibold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              Diabetes (3-Class)
            </button>
            <button
              onClick={() => onSelectSample('student_mental')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-all ${
                dataset.id === 'student_mental_health'
                  ? 'bg-blue-600/25 text-blue-300 border-blue-500/50 font-semibold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              Student Mental Health
            </button>
            <button
              onClick={() => onSelectSample('student_dropout')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-all ${
                dataset.id === 'student_dropout_success'
                  ? 'bg-blue-600/25 text-blue-300 border-blue-500/50 font-semibold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              Student Dropout (3-Class)
            </button>
            <button
              onClick={() => onSelectSample('housing')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-all ${
                dataset.id === 'california_housing'
                  ? 'bg-blue-600/25 text-blue-300 border-blue-500/50 font-semibold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              Housing (Regression)
            </button>
            <button
              onClick={() => onSelectSample('sensor')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-all ${
                dataset.id === 'sensor_fleet_unsupervised'
                  ? 'bg-blue-600/25 text-blue-300 border-blue-500/50 font-semibold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              Sensors (Unsupervised)
            </button>
            <button
              onClick={() => onSelectSample('clean_benchmark')}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg border transition-all ${
                dataset.id === 'clean_benchmark_nominal'
                  ? 'bg-emerald-600/25 text-emerald-300 border-emerald-500/50 font-semibold'
                  : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
              }`}
            >
              Clean Benchmark (0-Fault)
            </button>
          </div>
        </div>

        {/* Upload & Dynamic Target Selector Controls */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <label className="cursor-pointer flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-blue-600/15 border border-blue-500/30 text-blue-400 hover:bg-blue-600/25 transition-all text-xs font-medium">
              <Upload className="w-3.5 h-3.5" />
              <span>Upload CSV / Excel (.xlsx, .xls)</span>
              <input
                type="file"
                accept=".csv, .xlsx, .xls"
                className="hidden"
                onChange={handleFileUpload}
              />
            </label>

            <button
              onClick={onOpenManualModal}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/25 transition-all text-xs font-medium"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Manual Dataset Studio</span>
            </button>

            <button
              onClick={() => downloadHealedDatasetCsv(dataset.name, dataset.rows, dataset.columns)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 hover:border-emerald-500/40 text-slate-300 hover:text-emerald-400 transition-all text-xs font-medium"
              title="Download current working dataset as CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={() => downloadHealedDatasetXlsx(dataset.name, dataset.rows, dataset.columns)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 hover:border-teal-500/40 text-slate-300 hover:text-teal-400 transition-all text-xs font-medium"
              title="Download current working dataset as Excel XLSX"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Export XLSX</span>
            </button>

            {uploadError && (
              <span className="text-xs text-rose-400 flex items-center gap-1 font-mono">
                <AlertCircle className="w-3.5 h-3.5" />
                {uploadError}
              </span>
            )}
          </div>

          {/* Dynamic Target Column Selector */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400 font-medium">Target Feature:</span>
            <select
              value={dataset.targetColumn}
              onChange={(e) => onSelectTargetColumn(e.target.value)}
              className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-1.5 font-mono focus:outline-none focus:border-blue-500 max-w-sm"
            >
              <option value="AUTO_ALL_ELIGIBLE" className="font-bold text-amber-400 bg-slate-900">
                ★ AUTO EVALUATE ALL ELIGIBLE TARGETS
              </option>
              <option value="" className="text-slate-400">
                None / Unsupervised (Anomaly Detection)
              </option>
              {dataset.columns.map((col) => (
                <option key={col.name} value={col.name}>
                  {col.name} ({col.type}) {col.isIdentifier ? '— [ID / Excluded]' : col.name === dataset.autoSuggestedTarget ? '— ★ Auto Suggested' : ''}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* ====================================================
          MULTI-TARGET ANALYSIS LEADERBOARD (When Active)
          ==================================================== */}
      {isMultiTargetMode && dataset.multiTargetResults && (
        <div className="p-5 rounded-xl bg-[#0F172A] border border-amber-500/30 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-bold text-white font-mono">
                Automatic Multi-Target Evaluation Matrix
              </h2>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              Zero Data Leakage Enforced
            </span>
          </div>
          <p className="text-xs text-slate-400">
            A separate machine learning model was trained and evaluated for each eligible column. Identifiers and unsuitable features were automatically excluded.
          </p>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider">
                  <th className="py-2.5 px-3">Candidate Target Column</th>
                  <th className="py-2.5 px-3">Identified Task</th>
                  <th className="py-2.5 px-3">Eligibility Status</th>
                  <th className="py-2.5 px-3">Performance Metric / Reason</th>
                  <th className="py-2.5 px-3 text-right">Training Time</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {dataset.multiTargetResults.map((t) => {
                  return (
                    <tr key={t.targetName} className="hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-semibold text-slate-200">
                        {t.targetName}
                      </td>
                      <td className="py-2.5 px-3 capitalize">
                        {t.taskType.replace(/_/g, ' ')}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                          t.eligible
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}>
                          {t.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3">
                        {t.eligible ? (
                          <span className="text-emerald-400 font-bold">
                            {t.scoreFormatted}
                          </span>
                        ) : (
                          <span className="text-slate-500 text-[11px]">
                            {t.exclusionReason}
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-right tabular-nums text-slate-400">
                        {t.trainTimeMs > 0 ? `${t.trainTimeMs}ms` : '—'}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        {t.eligible && (
                          <button
                            onClick={() => onSelectTargetColumn(t.targetName)}
                            className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-sans font-medium transition-colors"
                          >
                            Set As Active Target
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Column Quality & Schema Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-xl bg-[#0F172A] border border-slate-800">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
            Total Ingested Rows
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-1 tabular-nums">
            {dataset.rows.length.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Original untouched raw data preserved
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0F172A] border border-slate-800">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
            Total Features Scanned
          </div>
          <div className="text-2xl font-bold font-mono text-white mt-1 tabular-nums">
            {dataset.columns.length}
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            {dataset.columns.filter((c) => c.type === 'numeric').length} numeric · {dataset.columns.filter((c) => c.type === 'categorical').length} categorical
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0F172A] border border-slate-800">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
            Completeness
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1 tabular-nums">
            {completeness}%
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            {missingCells} total missing values
          </div>
        </div>

        <div className="p-4 rounded-xl bg-[#0F172A] border border-slate-800">
          <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
            Target Feature & Task
          </div>
          <div className="text-base font-bold font-mono text-blue-400 mt-1 truncate">
            {isMultiTargetMode ? 'AUTO EVALUATE ALL TARGETS' : dataset.targetColumn || 'None (Unsupervised)'}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5 capitalize">
            {isMultiTargetMode ? 'Multi-Output Analysis' : dataset.taskType.replace(/_/g, ' ')}
          </div>
        </div>
      </div>

      {/* Schema Statistics Table */}
      <div className="p-5 rounded-xl bg-[#0F172A] border border-slate-800">
        <h2 className="text-sm font-semibold text-slate-100 mb-1">
          Feature Schema & Descriptive Statistics
        </h2>
        <p className="text-xs text-slate-400 mb-4">
          Automated type inference, IQR outlier detection, and distribution characteristics calculated per column
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider font-mono">
                <th className="py-2.5 px-3">Feature Name</th>
                <th className="py-2.5 px-3">Inferred Role</th>
                <th className="py-2.5 px-3 text-right">Missing</th>
                <th className="py-2.5 px-3 text-right">Unique</th>
                <th className="py-2.5 px-3 text-right">Outliers (IQR)</th>
                <th className="py-2.5 px-3 text-right">Mean</th>
                <th className="py-2.5 px-3 text-right">Median</th>
                <th className="py-2.5 px-3 text-right">Min</th>
                <th className="py-2.5 px-3 text-right">Max</th>
                <th className="py-2.5 px-3 text-right">Std Dev</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
              {dataset.columns.map((col) => {
                const isTarget = col.name === dataset.targetColumn;
                return (
                  <tr key={col.name} className={`hover:bg-slate-800/40 transition-colors ${isTarget ? 'bg-blue-600/10' : ''}`}>
                    <td className="py-2 px-3 font-semibold text-slate-200 flex items-center gap-1.5">
                      <span>{col.name}</span>
                      {isTarget && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 border border-blue-500/40 uppercase">
                          Target
                        </span>
                      )}
                      {col.isIdentifier && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 border border-slate-700">
                          ID
                        </span>
                      )}
                      {col.isConstant && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                          Constant
                        </span>
                      )}
                    </td>
                    <td className="py-2 px-3">
                      <span className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                        col.type === 'numeric'
                          ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                          : col.type === 'identifier'
                          ? 'bg-slate-800 text-slate-400'
                          : col.type === 'datetime'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          : 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                      }`}>
                        {col.type}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-slate-400">
                      {col.missingCount}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-slate-300">
                      {col.uniqueCount}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-amber-400">
                      {col.outlierCount ?? 0}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-slate-300">
                      {col.mean !== undefined ? col.mean : '—'}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-slate-300">
                      {col.median !== undefined ? col.median : '—'}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-slate-400">
                      {col.min !== undefined ? col.min : '—'}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-slate-400">
                      {col.max !== undefined ? col.max : '—'}
                    </td>
                    <td className="py-2 px-3 text-right tabular-nums text-slate-400">
                      {col.std !== undefined ? col.std : '—'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Live Data Preview Table */}
      <div className="p-5 rounded-xl bg-[#0F172A] border border-slate-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-100">
              Working Memory In-Memory Data Preview
            </h2>
            <p className="text-xs text-slate-400">
              Showing {filteredRows.length} rows (Page {currentPage} of {totalPages})
            </p>
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search table values..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-slate-900 border border-slate-700 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 w-56 focus:outline-none focus:border-blue-500 font-mono"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider font-mono">
                {dataset.columns.map((col) => (
                  <th key={col.name} className="py-2 px-3 whitespace-nowrap">
                    {col.name}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
              {paginatedRows.map((row, idx) => (
                <tr key={idx} className="hover:bg-slate-800/30 transition-colors">
                  {dataset.columns.map((col) => {
                    const val = row[col.name];
                    const isNull = val === null || val === undefined || val === '';
                    return (
                      <td key={col.name} className="py-2 px-3 whitespace-nowrap">
                        {isNull ? (
                          <span className="text-[10px] text-rose-400/80 italic font-mono">
                            null
                          </span>
                        ) : (
                          String(val)
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination controls */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-800 text-xs text-slate-400 font-mono">
            <span>
              Showing {(currentPage - 1) * rowsPerPage + 1} to{' '}
              {Math.min(currentPage * rowsPerPage, filteredRows.length)} of {filteredRows.length}
            </span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 transition-colors"
              >
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
              <span className="px-2 font-semibold text-slate-200">
                {currentPage} / {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 transition-colors"
              >
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
