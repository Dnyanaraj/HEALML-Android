/**
 * HEALML - Navbar Component
 * Strictly adheres to the 3-Zone Top Bar Contract:
 * [Brand Zone] — [Nav Links (single-line)] — [1 Primary Action CTA]
 */

import React from 'react';
import { ShieldCheck, Play, RefreshCw, Cpu } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isRunningPipeline: boolean;
  onRunPipeline: () => void;
  pipelineHealth: 'OPTIMAL' | 'DEGRADED' | 'HEALING' | 'ERROR';
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isRunningPipeline,
  onRunPipeline,
  pipelineHealth,
}) => {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'dataset', label: 'Dataset' },
    { id: 'pipeline', label: 'Pipeline Flow' },
    { id: 'faults', label: 'Faults & Healing' },
    { id: 'evaluation', label: 'Model Evaluation' },
    { id: 'anomalies', label: 'Isolation Forest' },
    { id: 'logs', label: 'Recovery Logs' },
    { id: 'code', label: 'Code & Run Guides' },
  ];

  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-[#0F172A] border-b border-slate-800 shrink-0 sticky top-0 z-40">
      {/* Zone 1: Single text element wordmark */}
      <div 
        onClick={() => setActiveTab('dashboard')} 
        className="flex items-center gap-3 cursor-pointer whitespace-nowrap shrink-0 group"
      >
        <div className="w-9 h-9 rounded-lg bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 group-hover:bg-blue-600/30 transition-colors">
          <ShieldCheck className="w-5 h-5 text-blue-400" />
        </div>
        <div>
          <span className="text-lg font-bold tracking-tight text-white group-hover:text-blue-400 transition-colors">
            HEALML
          </span>
          <span className="hidden sm:inline-block text-xs text-slate-400 ml-2 font-mono">
            Self-Healing MLOps
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation links, single-line text with hover states */}
      <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-slate-400">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`whitespace-nowrap shrink-0 transition-colors text-xs tracking-wide py-1 border-b-2 ${
              activeTab === item.id
                ? 'text-blue-400 border-blue-500 font-semibold'
                : 'text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            {item.label}
          </button>
        ))}
      </nav>

      {/* Zone 3: 1 Primary Action CTA */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onRunPipeline}
          disabled={isRunningPipeline}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-sm shadow-blue-500/20 transition-all whitespace-nowrap shrink-0"
        >
          {isRunningPipeline ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-white" />
              <span>Executing Pipeline...</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current text-white" />
              <span>Run Pipeline</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};
